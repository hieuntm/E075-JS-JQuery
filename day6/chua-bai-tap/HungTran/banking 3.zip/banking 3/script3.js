const atms = [];

class AccountNumberATM {
    constructor(username) {
        this.balance = 0;
        this.username = username;
        this.password = "123456";
        this.history = [];
    }

    napTien(soLuong) {
        this.balance += soLuong;
        this.history.unshift(`Nạp: +${soLuong}`);
    }

    rutTien(soLuong) {
        if (this.balance >= soLuong) {
            this.balance -= soLuong;
            this.history.unshift(`Rút: -${soLuong}`);
        } else {
            alert('Số dư không đủ để rút tiền.');
        }
    }

    transfer(tenTKchuyenToi, soLuong) {
        const accountTo = atms.find(account => account.username === tenTKchuyenToi);
        if (accountTo && this.balance >= soLuong) {
            this.balance -= soLuong;
            accountTo.balance += soLuong;
            this.history.unshift(`Chuyển tới ${tenTKchuyenToi}: -${soLuong}`);
            accountTo.history.unshift(`Nhận từ ${this.username}: +${soLuong}`);
        } else {
            alert('Chuyển tiền thất bại');
        }
    }
}

const ATM1 = new AccountNumberATM("account1");
ATM1.balance = 1000;
atms.push(ATM1);
const ATM2 = new AccountNumberATM("account2");
ATM2.balance = 2000;
atms.push(ATM2);

let currentAccount = null;

console.log(atms);

function dangNhap() {
    const username1 = document.getElementById("username").value;
    const password1 = document.getElementById("password").value;
    let foundAccount = false;
    for (let account of atms) {
        if (account.username === username1 && account.password === password1) {
            currentAccount = account;
            console.log("Đăng nhập thành công");
            foundAccount = true;
            displayBankInformation(account);
            break;
        }
    }

    if (!foundAccount) {
        console.log("Đăng nhập thất bại");
        displayError();
    }
}

function displayError() {
    const p = document.getElementById("error-message");
    p.style.color = 'red';
    p.style.display = "inline";
    p.innerHTML = "Mật khẩu không đúng hoặc tài khoản không tồn tại";
}

function displayBankInformation(account) {
    const p = document.getElementById("error-message");
    if (p) {
        p.style.display = "none";
    }
    const table = document.getElementById("dangNhapTable");
    if (table) {
        table.style.display = "none";
    }

    const bank = document.getElementById("bank");
    if (bank) {
        bank.style.display = "block";
        const balance = document.getElementById("balance");
        balance.innerHTML = "Balance: $" + account.balance;
        displayHistory(account.history);
    }
}

function displayHistory(history) {
    const historyDiv = document.getElementById("history");
    historyDiv.innerHTML = "<h3>Lịch sử giao dịch:</h3>";
    history.forEach(item => {
        const p = document.createElement("p");
        p.innerHTML = item;
        historyDiv.appendChild(p);
    });
}

function napTien() {
    const soTienNap = parseFloat(document.getElementById("soTienNap").value);
    if (!isNaN(soTienNap) && soTienNap > 0) {
        currentAccount.napTien(soTienNap);
        updateBalance();
    } else {
        alert('Vui lòng nhập số tiền hợp lệ.');
    }
}

function rutTien() {
    const soTienRut = parseFloat(document.getElementById("soTienRut").value);
    if (!isNaN(soTienRut) && soTienRut > 0) {
        currentAccount.rutTien(soTienRut);
        updateBalance();
    } else {
        alert('Vui lòng nhập số tiền hợp lệ.');
    }
}

function chuyenTien() {
    const soTienChuyen = parseFloat(document.getElementById("soTienChuyen").value);
    const tenTKchuyenToi = document.getElementById("tenTKchuyenToi").value;
    if (!isNaN(soTienChuyen) && soTienChuyen > 0 && tenTKchuyenToi) {
        currentAccount.transfer(tenTKchuyenToi, soTienChuyen);
        updateBalance();
    } else {
        alert('Vui lòng nhập thông tin hợp lệ.');
    }
}

function updateBalance() {
    const balance = document.getElementById("balance");
    balance.innerHTML = "Balance: $" + currentAccount.balance;
    displayHistory(currentAccount.history);
}


